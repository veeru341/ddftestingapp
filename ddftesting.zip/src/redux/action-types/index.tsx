export enum ActionType {
    DEPOSIT = "deposit",
    WITHDRAW = "withdraw",
    EDITSCHEMA = "editschema",
    ISLOGGEDIN = "isloggedin",
    DELETESCHEMA = "deleteschema",
    JSONSTRUCTURE = "jsonstructure",
    JSONSTRUCTUREEDIT = "jsonstructureedit",
    JSONSTRUCTUREEDITSAVE = "jsonstructureeditsave"
}