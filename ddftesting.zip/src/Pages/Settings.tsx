import React, { useState } from 'react';
import JsonMaps from '../components/JsonMaps';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';

export default function Settings() {
  return (
    <div>
        <JsonMaps />
    </div>
  )
}