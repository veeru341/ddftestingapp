import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { Link } from "react-router-dom";
import FormRenderer from '@data-driven-forms/react-form-renderer/form-renderer';
import MuiFormTemplate from '@data-driven-forms/mui-component-mapper/form-template';
import componentMapper from '@data-driven-forms/mui-component-mapper/component-mapper';
import data from '../data'

const FormTemplate = (props : any) => <MuiFormTemplate {...props} showFormControls={false} />


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function BasicGrid() {
  return (
    <Grid container direction="row" justifyContent="center" alignItems="center" style={{ height: "90vh" }}>
      <Grid item style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", width: "450px" }}>
          <FormRenderer
            schema={data}
            FormTemplate={FormTemplate}
            componentMapper={componentMapper}
            onSubmit={console.log}
          />
        </div>
      </Grid>
    </Grid >
  );
}